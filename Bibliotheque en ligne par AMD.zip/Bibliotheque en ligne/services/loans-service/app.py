from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timedelta
import os, requests

from sqlalchemy import create_engine, Column, Integer, DateTime, Boolean
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./loans.db")
CATALOG_URL = os.getenv("CATALOG_URL", "http://localhost:8001")
PORT = int(os.getenv("PORT", "8002"))

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class LoanORM(Base):
    __tablename__ = "loans"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False)
    book_id = Column(Integer, nullable=False)
    borrowed_at = Column(DateTime, default=datetime.utcnow)
    due_at = Column(DateTime, default=lambda: datetime.utcnow() + timedelta(days=14))
    returned_at = Column(DateTime, nullable=True)

Base.metadata.create_all(bind=engine)

class LoanIn(BaseModel):
    user_id: int
    book_id: int

class LoanOut(LoanIn):
    id: int
    borrowed_at: datetime
    due_at: datetime
    returned_at: Optional[datetime]
    class Config:
        from_attributes = True

app = FastAPI(title="Loans Service", version="1.0.0")

@app.get("/health")
def health():
    return {"status": "ok", "service": "loans"}

@app.get("/loans", response_model=List[LoanOut])
def list_loans():
    db = SessionLocal()
    try:
        loans = db.query(LoanORM).order_by(LoanORM.borrowed_at.desc()).all()
        return loans
    finally:
        db.close()

@app.get("/loans/{loan_id}", response_model=LoanOut)
def get_loan(loan_id: int):
    db = SessionLocal()
    try:
        l = db.query(LoanORM).get(loan_id)
        if not l:
            raise HTTPException(404, "Loan not found")
        return l
    finally:
        db.close()

@app.post("/loans", response_model=LoanOut, status_code=201)
def create_loan(payload: LoanIn):
    # Vérifier disponibilité côté Catalog Service
    r = requests.get(f"{CATALOG_URL}/books/{payload.book_id}", timeout=5)
    if r.status_code != 200:
        raise HTTPException(400, "Book does not exist in catalog")
    book = r.json()
    if book["available_copies"] <= 0:
        raise HTTPException(400, "No available copies to loan")

    # Décrémenter la disponibilité
    r2 = requests.post(f"{CATALOG_URL}/books/{payload.book_id}/decrement", timeout=5)
    if r2.status_code != 200:
        raise HTTPException(400, "Failed to decrement availability")

    db = SessionLocal()
    try:
        loan = LoanORM(user_id=payload.user_id, book_id=payload.book_id)
        db.add(loan)
        db.commit()
        db.refresh(loan)
        return loan
    finally:
        db.close()

@app.post("/loans/{loan_id}/return", response_model=LoanOut)
def return_loan(loan_id: int):
    db = SessionLocal()
    try:
        l = db.query(LoanORM).get(loan_id)
        if not l:
            raise HTTPException(404, "Loan not found")
        if l.returned_at is not None:
            return l  # déjà rendu
        l.returned_at = datetime.utcnow()
        db.commit()
        db.refresh(l)
    finally:
        db.close()

    # Incrémenter la disponibilité dans le catalogue
    r = requests.post(f"{CATALOG_URL}/books/{l.book_id}/increment", timeout=5)
    if r.status_code != 200:
        # Ici on pourrait ajouter une file/saga pour garantir la cohérence
        pass
    return l
